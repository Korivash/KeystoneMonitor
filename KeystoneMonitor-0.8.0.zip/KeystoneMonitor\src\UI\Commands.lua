local _, ns = ...

function ns:RegisterSlashCommands()
    SLASH_KEYSTONEMONITOR1 = "/keystonemonitor"
    SLASH_KEYSTONEMONITOR2 = "/mplus"
    SLASH_KEYSTONEMONITOR3 = "/km"

    SlashCmdList.KEYSTONEMONITOR = function(message)
        local cmd = self:Trim((message or ""):lower())

        if cmd == "" or cmd == "menu" or cmd == "config" or cmd == "options" or cmd == "open" then
            self:ToggleOptionsUI()
            return
        end

        if cmd == "unlock" then
            self.db.profile.locked = false
            self:RefreshOptionsUI()
            self:RefreshVisibility()
            self:Render()
            self:Print("Unlocked. Drag to move.")
            return
        end

        if cmd == "lock" then
            self.db.profile.locked = true
            self:RefreshOptionsUI()
            self:RefreshVisibility()
            self:Render()
            self:Print("Locked.")
            return
        end

        if cmd == "show" then
            self.db.profile.showWhenUnlocked = true
            self:RefreshOptionsUI()
            self:RefreshVisibility()
            self:Render()
            self:Print("Frame will show while unlocked.")
            return
        end

        if cmd == "hide" then
            self.db.profile.showWhenUnlocked = false
            self:RefreshOptionsUI()
            self:RefreshVisibility()
            self:Render()
            self:Print("Frame hidden outside active runs.")
            return
        end

        if cmd == "reset" then
            self.db.profile.position.x = 0
            self.db.profile.position.y = 120
            self:RestorePosition()
            self:RefreshOptionsUI()
            self:Print("Position reset.")
            return
        end

        if cmd == "history" then
            local history = self.db.history or {}
            if #history == 0 then
                self:Print("No runs recorded yet.")
                return
            end
            self:Print("Recent runs:")
            for i = 1, math.min(#history, 10) do
                local run = history[i]
                local when = date("%m/%d %H:%M", run.at or 0)
                local levelText = (run.level and run.level > 0) and string.format(" +%d", run.level) or ""
                local resultText = ""
                if run.mode == "MYTHIC_PLUS" then
                    resultText = run.onTime and "  |cff7CFC00Timed|r" or "  |cffFF6666Depleted|r"
                end
                self:Print(string.format(
                    "%s  %s%s  %s  Deaths %d%s",
                    when,
                    run.name or "?",
                    levelText,
                    self:FormatTime(run.timeSec or 0),
                    run.deaths or 0,
                    resultText
                ))
            end
            return
        end

        if cmd == "resetrun" then
            self:ClearRunSnapshot()
            self._bossListKey = nil
            self:SyncChallengeState(true)
            self:Print("Current run tracking reset.")
            return
        end

        if cmd == "debug" then
            self.debugMode = not self:IsDebugModeEnabled()
            if self.debugMode then
                self:Print("Debug mode enabled. Tracking mode logs will print on zone/difficulty changes.")
                self:PrintDungeonModeDebug("MANUAL")
            else
                self:Print("Debug mode disabled.")
            end
            return
        end

        if cmd == "debug now" then
            self:PrintDungeonModeDebug("MANUAL")
            return
        end

        self:Print("Commands: /km, /km unlock, /km lock, /km show, /km hide, /km reset, /km history, /km resetrun, /km debug, /km debug now")
    end
end
