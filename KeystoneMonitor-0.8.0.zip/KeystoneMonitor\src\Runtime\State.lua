local _, ns = ...

local MODE_AUTO = "AUTO"
local MODE_MYTHIC_PLUS = "MYTHIC_PLUS"
local MODE_MYTHIC_ZERO = "MYTHIC_ZERO"
local MODE_HEROIC = "HEROIC"
local MODE_NORMAL = "NORMAL"
local MODE_FOLLOWER = "FOLLOWER"
local MODE_TIMEWALKING = "TIMEWALKING"

local VALID_MODES = {
    [MODE_AUTO] = true,
    [MODE_FOLLOWER] = true,
    [MODE_NORMAL] = true,
    [MODE_HEROIC] = true,
    [MODE_TIMEWALKING] = true,
    [MODE_MYTHIC_ZERO] = true,
    [MODE_MYTHIC_PLUS] = true,
}

local MYTHIC_PLUS_DIFFICULTIES = {
    [8] = true,
}

local MYTHIC_ZERO_DIFFICULTIES = {
    [23] = true,
}

local FOLLOWER_DIFFICULTIES = {
    [205] = true,
}

local TIMEWALKING_DIFFICULTIES = {
    [24] = true,
    [33] = true,
}

local function newRuntimeState()
    return {
        inChallenge = false,
        mode = MODE_MYTHIC_PLUS,
        challengeCompleted = false,
        completedOnTime = nil,
        completionTimeMs = nil,
        timerStarted = false,
        runStartTime = nil,
        runKey = nil,
        elapsed = 0,
        timeLimit = 0,
        timeLimits = {},
        mapID = nil,
        instanceID = nil,
        mapName = "Mythic+",
        level = 0,
        affixIDs = {},
        affixes = {},
        weeklyAffixIDs = {},
        weeklyAffixes = {},
        hasChallengersPeril = false,
        deathCount = 0,
        deathPenalty = 0,
        deathLog = {},
        forcesCurrent = 0,
        forcesTotal = 0,
        forcesCompleted = false,
        forcesCompletionTime = nil,
        bossesDone = 0,
        bossesTotal = 0,
        objectives = {},
    }
end

local function getCriteriaQuantity(info)
    local quantityString = info and info.quantityString
    if quantityString then
        local quantity = tonumber(quantityString:match("(%d+)"))
        if quantity then
            return quantity
        end
    end
    return tonumber(info and info.quantity) or 0
end

function ns:RefreshWeeklyAffixes()
    wipe(self.state.weeklyAffixIDs)
    wipe(self.state.weeklyAffixes)
    self._affixCacheDirty = true

    local affixIDs = {}

    if C_MythicPlus and C_MythicPlus.GetCurrentAffixes then
        local currentAffixes = C_MythicPlus.GetCurrentAffixes()
        if currentAffixes then
            for i = 1, #currentAffixes do
                local entry = currentAffixes[i]
                if entry and entry.id then
                    affixIDs[#affixIDs + 1] = entry.id
                    self.state.weeklyAffixIDs[#self.state.weeklyAffixIDs + 1] = entry.id
                end
            end
        end
    end

    if #affixIDs == 0 and C_ChallengeMode and C_ChallengeMode.GetActiveKeystoneInfo then
        local _, activeAffixIDs = C_ChallengeMode.GetActiveKeystoneInfo()
        if activeAffixIDs then
            for i = 1, #activeAffixIDs do
                affixIDs[#affixIDs + 1] = activeAffixIDs[i]
                self.state.weeklyAffixIDs[#self.state.weeklyAffixIDs + 1] = activeAffixIDs[i]
            end
        end
    end

    if C_ChallengeMode and C_ChallengeMode.GetAffixInfo then
        for i = 1, #affixIDs do
            local affixID = affixIDs[i]
            local name = C_ChallengeMode.GetAffixInfo(affixID)
            self.state.weeklyAffixes[#self.state.weeklyAffixes + 1] = self:CleanAffixName(name) or tostring(affixID)
        end
    end
end

function ns:GetWeeklyAffixSummary()
    if not self.state.weeklyAffixes or #self.state.weeklyAffixes == 0 then
        return nil
    end
    return table.concat(self.state.weeklyAffixes, ", ")
end

function ns:ResetRuntimeState()
    self.state = newRuntimeState()
    self._affixCacheDirty = true
end

function ns:IsChallengeActive()
    if not self:IsInMythicPlusInstance() then
        return false
    end

    if not C_ChallengeMode or not C_ChallengeMode.GetActiveChallengeMapID then
        return false
    end

    local mapID = C_ChallengeMode.GetActiveChallengeMapID()
    return mapID and mapID > 0
end

function ns:IsInMythicPlusInstance()
    local _, instanceType, difficultyID = GetInstanceInfo()
    local isMythicPlus = MYTHIC_PLUS_DIFFICULTIES[difficultyID] and true or false
    return instanceType == "party" and isMythicPlus
end

function ns:GetSelectedDungeonMode()
    local configured = self.db and self.db.profile and self.db.profile.dungeonMode
    if configured and VALID_MODES[configured] then
        return configured
    end
    return MODE_AUTO
end

function ns:GetCurrentDungeonMode()
    local _, instanceType, difficultyID, difficultyName = GetInstanceInfo()
    if instanceType ~= "party" then
        return nil
    end

    if FOLLOWER_DIFFICULTIES[difficultyID] then
        return MODE_FOLLOWER
    end

    if MYTHIC_PLUS_DIFFICULTIES[difficultyID] then
        return MODE_MYTHIC_PLUS
    end

    if MYTHIC_ZERO_DIFFICULTIES[difficultyID] then
        return MODE_MYTHIC_ZERO
    end

    if TIMEWALKING_DIFFICULTIES[difficultyID] then
        return MODE_TIMEWALKING
    end

    local localizedMythic = (PLAYER_DIFFICULTY6 or "Mythic"):lower()
    local localizedNormal = (PLAYER_DIFFICULTY1 or "Normal"):lower()
    local localizedHeroic = (PLAYER_DIFFICULTY2 or "Heroic"):lower()
    local localizedTimewalking = (PLAYER_DIFFICULTY_TIMEWALKER or "Timewalking"):lower()
    local currentDifficultyName = tostring(difficultyName or ""):lower()
    if currentDifficultyName ~= "" then
        if currentDifficultyName:find("follower", 1, true) then
            return MODE_FOLLOWER
        end
        if currentDifficultyName:find(localizedTimewalking, 1, true) then
            return MODE_TIMEWALKING
        end
        if currentDifficultyName:find(localizedMythic, 1, true) then
            return MODE_MYTHIC_ZERO
        end
        if currentDifficultyName:find(localizedHeroic, 1, true) then
            return MODE_HEROIC
        end
        if currentDifficultyName:find(localizedNormal, 1, true) then
            return MODE_NORMAL
        end
    end

    if difficultyID == 2 then
        return MODE_HEROIC
    end
    if difficultyID == 1 then
        return MODE_NORMAL
    end
    return nil
end

function ns:IsTrackedDungeonActive()
    local selectedMode = self:GetSelectedDungeonMode()
    local currentMode = self:GetCurrentDungeonMode()
    if selectedMode == MODE_AUTO then
        if not currentMode then
            return false, MODE_MYTHIC_PLUS
        end
        if currentMode == MODE_MYTHIC_PLUS then
            return self:IsChallengeActive(), currentMode
        end
        return true, currentMode
    end

    if selectedMode ~= currentMode then
        return false, selectedMode
    end

    if selectedMode == MODE_MYTHIC_PLUS then
        return self:IsChallengeActive(), selectedMode
    end
    return true, selectedMode
end

function ns:RefreshChallengeData()
    self:RefreshWeeklyAffixes()
    self:RefreshMeta()
    self:RefreshTimer()
    self:RefreshDeaths()
    self:RefreshObjectives()
end

function ns:RefreshMeta()
    local mode = self.state.mode or MODE_MYTHIC_PLUS
    local instanceName, _, _, _, _, _, _, instanceID = GetInstanceInfo()
    self.state.instanceID = tonumber(instanceID) or nil
    self._affixCacheDirty = true

    if mode ~= MODE_MYTHIC_PLUS then
        self.state.mapID = nil
        self.state.mapName = self:SafeMapName(instanceName or "Dungeon")
        self.state.timeLimit = 0
        self.state.level = 0
        wipe(self.state.affixIDs)
        wipe(self.state.affixes)
        return
    end

    if not C_ChallengeMode then
        return
    end

    local mapID = C_ChallengeMode.GetActiveChallengeMapID and C_ChallengeMode.GetActiveChallengeMapID()
    self.state.mapID = mapID or nil

    if mapID and C_ChallengeMode.GetMapUIInfo then
        local name, _, timeLimit = C_ChallengeMode.GetMapUIInfo(mapID)
        self.state.mapName = self:SafeMapName(name)
        self.state.timeLimit = tonumber(timeLimit) or 0
    else
        self.state.mapName = "Mythic+"
        self.state.timeLimit = 0
    end

    if C_ChallengeMode.GetActiveKeystoneInfo then
        local level, affixIDs = C_ChallengeMode.GetActiveKeystoneInfo()
        self.state.level = tonumber(level) or 0
        wipe(self.state.affixIDs)
        wipe(self.state.affixes)
        local hasPeril = false
        if affixIDs and C_ChallengeMode.GetAffixInfo then
            for i = 1, #affixIDs do
                local affixID = affixIDs[i]
                self.state.affixIDs[#self.state.affixIDs + 1] = affixID
                if affixID == 152 then
                    hasPeril = true
                end
                local name = C_ChallengeMode.GetAffixInfo(affixID)
                self.state.affixes[#self.state.affixes + 1] = self:CleanAffixName(name) or tostring(affixID)
            end
        end
        self.state.hasChallengersPeril = hasPeril
    else
        self.state.level = 0
        self.state.hasChallengersPeril = false
        wipe(self.state.affixIDs)
        wipe(self.state.affixes)
    end

    local limit = self.state.timeLimit
    if self.state.hasChallengersPeril and limit > 0 then
        local base = limit - 90
        self.state.timeLimits = { limit, (base * 0.8) + 90, (base * 0.6) + 90 }
    else
        self.state.timeLimits = { limit, limit * 0.8, limit * 0.6 }
    end
end

local affixDisplayCache = {}

function ns:GetActiveAffixDisplayData()
    if not self._affixCacheDirty then
        return affixDisplayCache
    end

    wipe(affixDisplayCache)
    self._affixCacheDirty = false

    if not C_ChallengeMode or not C_ChallengeMode.GetAffixInfo then
        return affixDisplayCache
    end

    local sourceIDs = self.state.affixIDs
    if not sourceIDs or #sourceIDs == 0 then
        sourceIDs = self.state.weeklyAffixIDs
    end
    if not sourceIDs or #sourceIDs == 0 then
        return affixDisplayCache
    end

    for i = 1, #sourceIDs do
        local affixID = sourceIDs[i]
        local name, description, fileDataID = C_ChallengeMode.GetAffixInfo(affixID)
        affixDisplayCache[#affixDisplayCache + 1] = {
            id = affixID,
            name = self:CleanAffixName(name) or tostring(affixID),
            description = description or "",
            icon = fileDataID,
        }
    end
    return affixDisplayCache
end

function ns:RefreshTimer()
    if not self.state.inChallenge then
        self.state.elapsed = 0
        self.state.timerStarted = false
        self.state.runStartTime = nil
        return
    end

    if self.state.mode == MODE_MYTHIC_PLUS then
        local elapsed = select(2, GetWorldElapsedTime(1))
        if elapsed then
            self.state.elapsed = tonumber(elapsed) or 0
            self.state.timerStarted = true
        end
        return
    end

    if self.state.challengeCompleted then
        return
    end

    if not self.state.runStartTime then
        self.state.runStartTime = GetTime()
    end
    self.state.elapsed = math.max(0, GetTime() - self.state.runStartTime)
    self.state.timerStarted = true
end

function ns:RefreshDeaths()
    if self.state.mode ~= MODE_MYTHIC_PLUS then
        self.state.deathCount = #(self.state.deathLog or {})
        self.state.deathPenalty = 0
        return
    end

    if not C_ChallengeMode or not C_ChallengeMode.GetDeathCount then
        self.state.deathCount = 0
        self.state.deathPenalty = 0
        return
    end

    local count, penalty = C_ChallengeMode.GetDeathCount()
    self.state.deathCount = tonumber(count) or 0
    self.state.deathPenalty = self:NormalizePenalty(penalty)
end

function ns:RefreshObjectives()
    local state = self.state
    if state.mode ~= MODE_MYTHIC_PLUS then
        return false
    end

    if not C_Scenario or not C_Scenario.GetStepInfo then
        return false
    end
    if not C_ScenarioInfo or not C_ScenarioInfo.GetCriteriaInfo then
        return false
    end

    local _, _, criteriaCount = C_Scenario.GetStepInfo()
    if not criteriaCount or criteriaCount <= 0 then
        if #state.objectives > 0 then
            wipe(state.objectives)
            return true
        end
        return false
    end

    local changed = false
    local rowCount = 0

    for i = 1, criteriaCount do
        local info = C_ScenarioInfo.GetCriteriaInfo(i)
        if info then
            if info.isWeightedProgress and info.totalQuantity and info.totalQuantity > 0 then
                local total = tonumber(info.totalQuantity) or 0
                if total > 0 and total ~= state.forcesTotal then
                    state.forcesTotal = total
                    changed = true
                end
                local quantity = getCriteriaQuantity(info)
                if quantity > state.forcesCurrent then
                    state.forcesCurrent = quantity
                    changed = true
                end
                if state.forcesTotal > 0
                        and state.forcesCurrent >= state.forcesTotal
                        and not state.forcesCompleted then
                    state.forcesCompleted = true
                    state.forcesCompletionTime = state.elapsed
                    changed = true
                end
            else
                rowCount = rowCount + 1
                local row = state.objectives[rowCount]
                if not row then
                    row = {}
                    state.objectives[rowCount] = row
                    changed = true
                end

                local text = info.description or ("Objective " .. i)
                local completed = info.completed and true or false

                if row.text ~= text then
                    row.text = text
                    changed = true
                end
                if row.completed ~= completed then
                    row.completed = completed
                    changed = true
                    if completed then
                        local criteriaElapsed = tonumber(info.elapsed) or 0
                        local worldElapsed = select(2, GetWorldElapsedTime(1))
                        if worldElapsed and worldElapsed > 0 then
                            row.doneAt = math.max(0, worldElapsed - criteriaElapsed)
                        else
                            row.doneAt = math.max(0, state.elapsed - criteriaElapsed)
                        end
                    else
                        row.doneAt = nil
                    end
                end
            end
        end
    end

    for i = #state.objectives, rowCount + 1, -1 do
        state.objectives[i] = nil
        changed = true
    end

    return changed
end

function ns:HandleChallengeCompleted()
    self.state.challengeCompleted = true

    if C_ChallengeMode and C_ChallengeMode.GetChallengeCompletionInfo then
        local completion = C_ChallengeMode.GetChallengeCompletionInfo()
        if completion then
            self.state.completedOnTime = completion.onTime and true or false
            self.state.completionTimeMs = completion.time or nil
        end
    end

    if self.state.completionTimeMs then
        self.state.elapsed = (tonumber(self.state.completionTimeMs) or 0) / 1000
        self.state.timerStarted = true
    end

    for i = 1, #self.state.objectives do
        local objective = self.state.objectives[i]
        if objective and not objective.completed then
            objective.completed = true
            objective.doneAt = tonumber(self.state.elapsed) or 0
        end
    end

    self:RecordRunSplits()
    self:UpdateDeathWatcher()
end

ns:ResetRuntimeState()
